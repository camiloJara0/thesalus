import{bo as t,r as i,k as n,b1 as o}from"./x8weUP9m.js";function u(r){const e=t({dir:i("ltr")});return n(()=>r?.value||e.dir?.value||"ltr")}function a(r,e="reka"){return`${e}-${o?.()}`}export{a,u};
