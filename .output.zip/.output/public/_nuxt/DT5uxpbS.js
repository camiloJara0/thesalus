const r=t=>t?new Date(t).toISOString().split("T")[0]:null;export{r as f};
