import{k as e,bo as r,aY as t}from"./C6x6jDvb.js";function a(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{a as u};
