import{k as e,bp as r,aZ as t}from"./Btc8Cmeu.js";function a(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{a as u};
