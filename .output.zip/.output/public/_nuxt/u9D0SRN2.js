import{k as e,bD as r,aN as t}from"./BjwRkqIn.js";function a(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{a as u};
