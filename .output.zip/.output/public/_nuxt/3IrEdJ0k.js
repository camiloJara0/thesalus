import{_ as e,o as c,c as t}from"./e2q1q3Dq.js";const s={},o={class:"flex flex-col gap-6 items-start"};function r(a,n){return c(),t("div",o)}const f=e(s,[["render",r]]);export{f as default};
