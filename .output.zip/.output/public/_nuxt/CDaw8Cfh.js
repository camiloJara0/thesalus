import{bn as t,r as n,k as i,b0 as o}from"./C6x6jDvb.js";function u(r){const e=t({dir:n("ltr")});return i(()=>r?.value||e.dir?.value||"ltr")}function a(r,e="reka"){return`${e}-${o?.()}`}export{a,u};
