import{bo as e,r as o,k as i}from"./CUoihzkV.js";function u(r){const t=e({dir:o("ltr")});return i(()=>r?.value||t.dir?.value||"ltr")}export{u};
