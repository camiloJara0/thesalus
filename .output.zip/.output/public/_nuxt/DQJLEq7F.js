import{b1 as r}from"./CUoihzkV.js";function s(t,e="reka"){return`${e}-${r?.()}`}export{s as u};
